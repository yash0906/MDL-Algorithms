+ run python3 eval.py YOUR_TEXT.txt
